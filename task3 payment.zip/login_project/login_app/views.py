from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,"home.html")
def login(request):
    cash=request.POST['amt']
    nam=request.POST['name']
    return render(request,"payment.html",{'amou':cash,'name':nam})